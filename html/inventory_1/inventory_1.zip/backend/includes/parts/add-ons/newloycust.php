

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SMHOS - CLI</title>
    <link rel="stylesheet" href="/css/bootstrap.min.css">

    <link rel="stylesheet" href="/css/all.css">
    <link rel="stylesheet" href="/css/keyboard.css">
    <link rel="icon" type="image/png" href="/assets/logo/logo.ico">


    <script src="/js/jquery.min.js"></script>
    <script src="/js/popper.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
    <script src="/js/query.js"></script>

    <script src="/js/sweetalert2@11"></script>
    <link rel="stylesheet" href="css/sweetalert.min.css">


    <script src="/js/classes/buttons.js"></script>

    <link rel="stylesheet" href="/css/anton.css">







</head>

<body style="height: 100vh; overflow: hidden">
<div class="container-fluid h-100 d-flex flex-wrap align-content-center ant-bg-light">
    <div class="row w-100 d-flex flex-wrap justify-content-center">
        <div class="col-sm-6">
            <div class="card w-100">
                <div class="card-header">
                    <strong class="card-title">ADD CUSTOMER</strong>
                </div>
                <div class="card-body p-2">


                </div>
            </div>
        </div>
    </div>
</div>
</body>

</html>

<script>


</script>

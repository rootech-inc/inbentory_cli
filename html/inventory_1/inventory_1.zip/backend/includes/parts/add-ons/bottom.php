</body>
</html>

<script>
    // make keypad draggable
    dragElement(document.getElementById("alphsKeyboard"))
    dragElement(document.getElementById("numericKeyboard"))
    loader('hide')
</script>